from app import app

print("in what the duck file")
